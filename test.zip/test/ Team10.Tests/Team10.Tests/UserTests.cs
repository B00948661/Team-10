using Microsoft.VisualStudio.TestTools.UnitTesting;
using Team10; // Namespace for your main project

namespace Team10.Tests
{
    [TestClass]
    public class UserTests
    {
        [TestMethod]
        public void User_Constructor_ShouldInitializeCorrectly()
        {
            // Arrange
            int userId = 1;
            string userName = "testUser";
            string password = "password123";  // Required parameter
            string email = "test@example.com";
            string address = "123 Main St";
            string city = "TestCity";
            string postcode = "12345";
            string phoneNumber = null; // Optional nullable parameter

            // Act
            User user = new User(userId, userName, password, email, address, city, postcode, phoneNumber);

            // Assert
            Assert.AreEqual(userName, user.UserName);
            Assert.AreEqual(password, user.Password);
            Assert.AreEqual(email, user.Email);
            Assert.AreEqual(address, user.Address);
            Assert.AreEqual(city, user.City);
            Assert.AreEqual(postcode, user.Postcode);
            Assert.AreEqual(phoneNumber, user.PhoneNumber);
        }

        [TestMethod]
        public void User_SetPassword_ShouldUpdatePassword()
        {
            // Arrange
            int userId = 1;
            string userName = "testUser";
            string password = "oldPassword";  // Initial password
            string email = "test@example.com";
            string address = "123 Main St";
            string city = "TestCity";
            string postcode = "12345";
            string phoneNumber = null;

            User user = new User(userId, userName, password, email, address, city, postcode, phoneNumber);

            // Act
            user.Password = "newPassword"; // Change password

            // Assert
            Assert.AreEqual("newPassword", user.Password); // Ensure the password was updated
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void User_Constructor_ShouldThrowExceptionForEmptyUsername()
        {
            // Arrange & Act
            // Attempt to create a User with an empty username
            User user = new User(1, "", "password123", "test@example.com", "123 Main St", "TestCity", "12345", null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void User_Constructor_ShouldThrowExceptionForNullUsername()
        {
            // Arrange & Act
            // Attempt to create a User with a null username
            User user = new User(1, null, "password123", "test@example.com", "123 Main St", "TestCity", "12345", null);
        }
    }
}
